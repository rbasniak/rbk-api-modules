﻿using Microsoft.VisualStudio.Coverage.Analysis;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace CodeCoverageGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            var root = "../../../../.";

            var coverageGroups = Directory.GetFiles(root, "*.coverage", SearchOption.AllDirectories)
                .GroupBy(x => new FileInfo(x).Directory.Parent.Parent.FullName).ToList();

            var coverageFiles = new List<string>();

            foreach (var file in coverageGroups)
            {
                var files = file.Select(x => new FileInfo(x));
                var coverageFile = files.OrderBy(x => x.CreationTime).Last();

                coverageFiles.Add(coverageFile.FullName);
            }

            var projects = Directory.GetFiles(root, "*.csproj", SearchOption.AllDirectories).ToList();

            var assemblies = projects.Select(x => new FileInfo(x).Directory.FullName + @"\bin\debug\net5.0\" + Path.GetFileNameWithoutExtension(x) + ".dll").ToList();
            var symbols = projects.Select(x => new FileInfo(x).Directory.FullName + @"\bin\debug\net5.0\" + Path.GetFileNameWithoutExtension(x) + ".pdb").ToList();

            foreach (var file in assemblies)
            {
                if (!File.Exists(file))
                {
                    Debugger.Break();
                }
            }

            foreach (var file in coverageGroups)
            {
                var files = file.Select(x => new FileInfo(x));
                var coverageFile = files.OrderBy(x => x.CreationTime).Last();

                coverageFiles.Add(coverageFile.FullName);
            }

            //foreach (var coverage in coverageFiles)
            //{
                using (CoverageInfo info = CoverageInfo.CreateFromFile(@"D:\Repositories\pessoal\libraries\rbk-api-modules-next\TestResults\5e96805e-7f70-4417-b876-767be3912539\rbasn_RB-NOTEBOOK 2021-03-17 23_18_55.coverage",
                    assemblies,
                    symbols))
                {
                    CoverageDS data = info.BuildDataSet();
                    data.WriteXml(@"D:\Repositories\pessoal\libraries\rbk-api-modules-next\TestResults\" + "results" + ".coveragexml");
                }
            //}
        }
    }
}
